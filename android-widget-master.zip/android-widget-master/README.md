# Widget Example in Android

This app demonstrates how to create a collection view widget to display a simple list of strings.

[This webcast goes through this example code for the Android Developer Nanodegree](https://www.youtube.com/watch?v=eKANzCs2pWM&feature=youtu.be).
